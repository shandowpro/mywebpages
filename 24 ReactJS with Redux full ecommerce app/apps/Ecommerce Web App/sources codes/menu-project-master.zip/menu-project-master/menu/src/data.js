export const items = [
    { id: Math.random(), title: 'وجبه فطار', description: 'وصف الفطار', price: '100 جنيه', category: 'فطار', imgUrl: "1.png" },
    { id: Math.random(), title: 'وجبه غدا', description: 'وصف الفطار', price: '80 جنيه', category: 'غدا', imgUrl: "2.png" },
    { id: Math.random(), title: 'وجبه عشاء', description: 'وصف الفطار', price: '40 جنيه', category: 'عشاء', imgUrl: "3.png" },
    { id: Math.random(), title: 'وجبه غدا ممتاز', description: 'وصف الفطار', price: '30 جنيه', category: 'غدا', imgUrl: "2.png" },
    { id: Math.random(), title: 'وجبه عشاء درجه اولى', description: 'وصف الفطار', price: '50 جنيه', category: 'عشاء', imgUrl: "1.png" },
    { id: Math.random(), title: 'وجبه فطار', description: 'وصف الفطار', price: '50 جنيه', category: 'فطار', imgUrl: "3.png" },
    { id: Math.random(), title: 'وجبه سناك', description: 'وصف الفطار', price: '50 جنيه', category: 'سناك', imgUrl: "3.png" }]