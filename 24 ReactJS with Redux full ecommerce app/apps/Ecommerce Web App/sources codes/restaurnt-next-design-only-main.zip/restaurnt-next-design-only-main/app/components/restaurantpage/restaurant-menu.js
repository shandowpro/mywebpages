export const RestaurantMenu = () => {
  return (
    <main className="menu-item">
      <div className="d-flex align-items-center justify-content-end w-100">
        <h5 className="price me-4">50$</h5>
        <h4>وجبه لحمه</h4>
      </div>
      <p>
        تفاصيل وصف الوجبه تفاصيل وصف الوجبه تفاصيل وصف الوجبه تفاصيل وصف الوجبه
        تفاصيل وصف الوجبه تفاصيل وصف الوجبه{" "}
      </p>

      <hr />
    </main>
  );
};
