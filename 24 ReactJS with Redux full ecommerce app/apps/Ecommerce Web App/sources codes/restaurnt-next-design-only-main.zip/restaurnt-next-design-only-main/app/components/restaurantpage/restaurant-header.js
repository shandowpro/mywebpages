import "../../style/rest-header.css";
const RestaurantHeader = () => {
  return (
    <div className="d-flex flex-column text-center">
      <div className="hero-container flex-column">
        <h1 className="hero-title">مطعم كنتاكي القاهرة</h1>
        <p className="hero-description">
          وصف مفصل للمطعم وتقيم وصف مفصل للمطعم وتقيم وصف مفصل للمطعم وتقيم
        </p>
      </div>
    </div>
  );
};

export default RestaurantHeader;
