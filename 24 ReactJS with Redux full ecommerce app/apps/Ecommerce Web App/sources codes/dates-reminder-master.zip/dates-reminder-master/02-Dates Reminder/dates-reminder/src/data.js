export const person = [{ id: '0', name: 'حسن', date: '5 مساء', img: 'p1.jpg' },
{ id: '1', name: 'محمد', date: '4 مساء', img: 'p1.jpg' },
{ id: '2', name: 'على', date: '3 مساء', img: 'p1.jpg' },
{ id: '3', name: 'محمود', date: '2 مساء', img: 'p1.jpg' },
{ id: '4', name: 'حسن', date: '1 مساء', img: 'p1.jpg' },
{ id: '5', name: 'حسن', date: '1 مساء', img: 'p1.jpg' },
{ id: '6', name: 'حسن', date: '1 مساء', img: 'p1.jpg' },]