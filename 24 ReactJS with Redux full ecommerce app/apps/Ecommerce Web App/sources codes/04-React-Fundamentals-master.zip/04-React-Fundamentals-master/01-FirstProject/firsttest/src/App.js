
import React ,{useReducer} from 'react'

import FetchAxios from './component/FetchAxios'
const App = () => {
    
    return (
        <div>
        <FetchAxios />
        </div>
    )
}

export default App;