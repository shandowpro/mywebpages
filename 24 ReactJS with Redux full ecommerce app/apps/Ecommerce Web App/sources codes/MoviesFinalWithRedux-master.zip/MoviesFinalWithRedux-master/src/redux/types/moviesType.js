export const AllMOVIES = "AllMOVIES"
export const MovieApi = "https://api.themoviedb.org/3/movie/popular?api_key=355f3cc55c1a5f8fb6f7b79d7541faea&language=ar&page=1"