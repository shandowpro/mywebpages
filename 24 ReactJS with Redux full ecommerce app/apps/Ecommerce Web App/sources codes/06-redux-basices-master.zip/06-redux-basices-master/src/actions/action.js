
import { INCREMENT } from '../type/type'
export const inc = () => {
    return {
        type: INCREMENT
    }
}