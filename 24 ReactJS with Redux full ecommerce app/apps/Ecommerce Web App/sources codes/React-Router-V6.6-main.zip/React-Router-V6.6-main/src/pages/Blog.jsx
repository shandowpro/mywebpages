import {Outlet} from "react-router-dom";

export const Blog = () => {
    return (
        <>main blog
        <Outlet />
        </>
    );
}