export const About = () => {
    return (
        <>about page</>
    );
}